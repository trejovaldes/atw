<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <script>
     
        function signup()
      {

          var alt="";
          var x=document.forms["signupform"]["nombre"].value;
          if (x==null || x=="")
            {
              alt +="ingrese su nombre\n";
              
            
            }
         var y=document.forms["signupform"]["apellido"].value;
         if (y==null || y=="")
            {
              
              alt += "Ingrese su apellido\n";
              
            }
			var x=document.forms["signupform"]["telefono"].value;
          if (x==null || x=="")
            {
              alt +="Ingrese su telefono\n";
              
            
            }
          var z=document.forms["signupform"]["email"].value;
          var atpos=z.indexOf("@");
          var dotpos=z.lastIndexOf(".");
              
           if (atpos<1 || dotpos<atpos+2 || dotpos+2>=z.length)
              {
             alt += "Ingrese un correo valido\n";
             
              }
         
          var v=document.forms["signupform"]["contraseña"].value; 
         
          if (v==null || v=="")
            {
              alt += "Ingrese su contraseña\n";
                 
            }
         var t=document.forms["signupform"]["contraseña2"].value; 
         if (t==null || t=="")
            {
              alt += "Vuelva a ingresar su contraseña\n";
                
            }
			 if (v != t)
            {
              alt += "Las contraseñas deben de coincidir\n";
                 
            }
         
        if (alt != "")
             {
               alert(alt);
              return false;
             }
			 else {
			 	form.Submit()
			 }
}

     </script>
    </head>
    <style type="text/css">
	#contenair{
		height: 100%;
		width: 100%;
		
	}
	#r{
		margin-top: 5%;
		margin-bottom: 50px;
		margin-right: 20px;
		float: right;
		height:95%;
		width:35%;
		background-color: #b7bcbd;
		
	}
	#l
	{
		margin-top: 5%;
		margin-bottom: 50px;
		margin-left:20px;
		float: left;
		width: 60%;
                
	}
	</style>
    <body>
    
        <?php
        echo 'hola mundo';// put your code here
        
        ?>
        <div id="l" align="center">
<h2  align="center" style="color:blue">Bienvenido a mi TallerSV </h2>
<h3 align="center"><u><i>Crear usuario</i></u></h3>
<body aling = "center" background color = "blue">
<table> 
 <form method="POST" name="signupform" action="index.php"  onSubmit="return signup();" >
		 <tr>
		<td height="40">Nombre:</td>
		<td><input name="primernombre" type="text" id="firstname" size="40" />
		
		</td>
	</tr>
	<tr>
		<td height="40">Apellido:</td>
		<td><input name="apellido" type="text" id="lastname" size="40"  />
		
		</td>
	</tr>
	<tr>
		<td height="40">Telefono:</td>
		<td><input name="telefono" type="text" id="daytimephone" size="40" class="phone" />
		
		</td>
	</tr>
	<tr>
		<td height="40">E-mail:</td>
		<td><input name="email" type="text" id="email" size="40"  />
		
		</td>
	</tr>
	
	<tr>
		<td height="40">Contraseña:</td>
		<td><input name="contraseña" type="password" id="password1" size="40" />
		
		</td>
	</tr>
	<tr>
		<td height="40">Confirmar Contraseña:</td>
		<td><input name="contraseña2" type="password" id="password2" size="40" />
		
		</td>
	</tr>
    <br>
	<tr>
		<td height="40">Departamento</td>
		<td><input name="departamento" type="text" id="city" size="40"  />
		</td>
	</tr>
    <br>
	<tr>
	<td align="center" colspan="2"><input type="submit" name="Submit" value="Crear" /></td>
		<td align="right" colspan="2"><input type="reset" name="reset" value="Reset"  /></td></tr>
        <td align="left" colspan="2"><input type="button" onClick="CrearCita.php" value="Cita"  /></td></tr>
    </form>
   </table>
</div>
    </body>
</html>
