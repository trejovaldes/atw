<?php
 
	if(isset($_POST["enviar"])) {
 
		require("serv.php");
 
			$loginNombre = $_POST["usuario"];
			$loginPassword = $_POST["password"];
 
			$consulta = "SELECT * FROM admin_user WHERE usuario='$loginNombre' AND password='$loginPassword'";
 
			if($resultado = $mysqli->query($consulta)) {
				while($row = $resultado->fetch_array()) {
 
					$userok = $row["usuario"];
					$passok = $row["password"];
				}
				$resultado->close();
			}
			$mysqli->close();
 
 
			if(isset($loginNombre) && isset($loginPassword)) {
 
				if($loginNombre == $userok && $loginPassword == $passok) {
 
					session_start();
					$_SESSION["logueado"] = TRUE;
					header("Location: admin.php");
 
				}
				else {
					Header("Location: logeo.php?error=login");
				}
 
			}
 
		} else {
			header("Location: /login/logeo.php");
		}
 
 ?>
