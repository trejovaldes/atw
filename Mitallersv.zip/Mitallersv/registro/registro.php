<?php
session_start();
require 'conexion.php';
?>
<?php
if (isset($_REQUEST['registrar']) && isset($_REQUEST['reg_agree'])) {
	if ($_REQUEST['contrasena'] === $_REQUEST['contrasenaConfirmar']) {
	$usuario = $_REQUEST['usuario'];
	$password = $_REQUEST['contrasena'];

	$encriptar = ($password);
	$conexion->query("INSERT INTO admin_user (usuario,password) VALUES ('$usuario', '$encriptar')");
	$_SESSION['logged'] = "Logged";
	$_SESSION['usuario'] = $usuario;
	$_SESSION['contrasena'] = $encriptar;
        
	header("Location:/PhpProject1/login/index.php");
        
	} else {
		echo "<div class='error'><span>Las Contraseñas no son iguales</span></div>";
	}
} elseif (isset($_REQUEST['registrar']) && isset($_REQUEST['reg_agree']) === FALSE) {
	echo "<div class='error'><span>Necesitas Estar de Acuerdo con los Términos y Condiciones</span></div>";
}
?>
<!DOCTYPE html>
<html lang="es">
    <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<head>
    <div class="w3-top">
  <div class="w3-bar w3-black w3-card-2">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="/PhpProject1/inicio.php"class="w3-bar-item w3-button w3-padding-large">Inicio</a>
       <div class="w3-dropdown-hover w3-hide-small">
      </div>
    </div>
    <a href="javascript:void(0)" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fa fa-search"></i></a>
  </div>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title>Registrarse</title>
	<link rel="stylesheet" type="text/css" href="http://netdna.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
	<link href='http://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>
<body>
<!-- REGISTRATION FORM -->
<div class="text-center register" style="padding-top:50px">
    <div class="logo">Registro</div>
	<!-- Main Form -->
	<div class="login-form-1">
		<form id="register-form" class="text-left" method="post">
			<div class="login-form-main-message"></div>
			<div class="main-login-form">
				<div class="login-group">
					<div class="form-group">
						<label for="reg_username" class="sr-only">Usuario</label>
						<input type="text" class="form-control" id="reg_username" name="usuario" placeholder="Usuario">
					</div>
					<div class="form-group">
						<label for="reg_password" class="sr-only">Contraseña</label>
						<input type="password" class="form-control" id="reg_password" name="contrasena" placeholder="Contraseña">
					</div>
					<div class="form-group">
						<label for="reg_password_confirm" class="sr-only">Confirme Contraseña</label>
						<input type="password" class="form-control" id="reg_password_confirm" name="contrasenaConfirmar" placeholder="Confirme contraseña">
					</div>
					
					<div class="form-group login-group-checkbox">
						<input type="checkbox" class="" id="reg_agree" name="reg_agree">
						<label for="reg_agree">Estoy de acuerdo con los términos y condiciones</label>
					</div>
				</div>
				<button type="submit" class="login-button" name="registrar"><i class="fa fa-chevron-right"></i></button>
			</div>
			<div class="etc-login-form">
                            <p>Ya tiene una cuenta? <a href="./../login/index.php">Login Aquí</a></p>
			</div>
		</form>
	</div>
	<!-- end:Main Form -->
</div>
</body>
</html>