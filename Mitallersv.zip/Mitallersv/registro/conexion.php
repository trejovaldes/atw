<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$base_de_datos = 'pruebas';

$conexion = new mysqli($host, $user, $pass, $base_de_datos);
?>
