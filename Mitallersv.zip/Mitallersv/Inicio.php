<!DOCTYPE html>
<html>
<title>Mi taller sv</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: "Lato", sans-serif}
.mySlides {display: none}
</style>
<body>

<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-black w3-card-2">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="#mitallersv" class="w3-bar-item w3-button w3-padding-large">Inicio</a>
    <a href="./login/index.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Log In</a>
    <a href="#servicios" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Servicios</a>
    <a href="#contact" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Contactanos</a>
    <div class="w3-dropdown-hover w3-hide-small">
      </div>
    </div>
    <a href="javascript:void(0)" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fa fa-search"></i></a>
  </div>
</div>


<!-- Page content -->
<div class="w3-content" style="max-width:2000px;margin-top:46px">

  <!-- Automatic Slideshow Images -->
  <div class="mySlides w3-display-container w3-center">
      <img src="benz.jpg" style="width:100%">
    <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
      <h3>Dale manteminiento a tu carro!!!</h3>
      <p><b>Haz tu cita ya!</b></p>   
    </div>
  </div>
  <div class="mySlides w3-display-container w3-center">
      <img src="ferrari.jpg" style="width:100%">
    <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
      <h3>Experiencia</h3>
      <p><b>Los mejores mecanicos</b></p>    
    </div>
  </div>
  <div class="mySlides w3-display-container w3-center">
      <img src="vettel.jpg" style="width:100%">
    <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
      <h3>Rendimiento</h3>
      <p><b>Disfruta tu carro</b></p>    
    </div>
  </div>

  <!-- The Band Section -->
  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px" id="mitallersv">
    <h2 class="w3-wide">MI TALLER SV</h2>
    <p class="w3-opacity"><i>Estamos para servirte</i></p>
    <p class="w3-justify">Como empresa de servicios nuestros valores se corresponden con la satisfacción de nuestros clientes y son ellos, junto con nuestros colaboradores, los que constituyen el fundamento de los valores de Mi taller sv, valores que nos reafirman y nos diferencian de nuestros competidores.</p>
    <p class ="w3-justify">Ser Mi taller sv significa ser parte de un equipo único centrado en el futuro en el que las personas son el recurso más valioso. 
Juntos competimos en el mercado nacional y los mercados de todo el mundo.  
Juntos hemos elaborado la Visión, Misión y Valores que son la esencia misma de sentir parte de Mi taller sv y que nos guían a medida que abordamos nuestros desafíos cotidianos.</p>
    <h2 class="w3-wide">Misión</h2>
    <p  class ="w3-justify">Dar respuesta a los requerimientos de servicios de automovilismo, de manera oportuna y eficiente para nuestros clientes, ofreciendo servicios de calidad</p>
    <h2 class="w3-wide">Visión</h2>
    <p  class ="w3-justify">Queremos lograr que el cliente tenga confianza en nuestros servicios y en nuestro equipo de profesionales, gozando siempre de un trato cercano, honesto y confiable.</p>
    <p class = "w3-justify">Mi taller sv, Excelencia salvadoreña que hace que El Salvador sueñe</p>
    <div class="w3-row w3-padding-32">
      <div class="w3-third" id="servicios">
        <p>Cambio de aceite</p>
        <img src="aceite.jpg" class="w3-round w3-margin-bottom" alt="desde $25" style="width:84%">
      </div>
      <div class="w3-third">
        <p>Alineado y rotacion de llantas</p>
        <img src="rotacion.jpg" class="w3-round w3-margin-bottom" alt="desde $3" style="width:100%">
      </div>
      <div class="w3-third">
        <p>Mecanica general</p>
        <img src="engine.jpg" class="w3-round" alt="Random Name" style="width:90%">
      </div>
    </div>
  </div>

  <!-- The Contact Section -->
  <div class="w3-container w3-content w3-padding-64" style="max-width:800px" id="contact">
    <h2 class="w3-wide w3-center">CONTACTANOS</h2>
    <p class="w3-opacity w3-center"><i>Dejanos tus sugerencias!</i></p>
    <div class="w3-row w3-padding-32">
      <div class="w3-col m6 w3-large w3-margin-bottom">
        <i class="fa fa-map-marker" style="width:30px"></i> Antiguo Cuscatlan,Es<br>
        <i class="fa fa-phone" style="width:30px"></i> Telefono: 022017<br>
        <i class="fa fa-envelope" style="width:30px"> </i> Email: mitallersv@ujmd.edu.sv<br>
      </div>
      <div class="w3-col m6">
        <form action="/action_page.php" target="_blank">
          <div class="w3-row-padding" style="margin:0 -16px 8px -16px">
            <div class="w3-half">
              <input class="w3-input w3-border" type="text" placeholder="Name" required name="Name">
            </div>
            <div class="w3-half">
              <input class="w3-input w3-border" type="text" placeholder="Email" required name="Email">
            </div>
          </div>
          <input class="w3-input w3-border" type="text" placeholder="Message" required name="Message">
          <button class="w3-button w3-black w3-section w3-right" type="submit">Enviar</button>
        </form>
      </div>
    </div>
  </div>
  
<!-- End Page Content -->
</div>


<!-- Footer -->
<footer class="w3-container w3-padding-64 w3-center w3-opacity w3-light-grey w3-xlarge">
  <p class="w3-medium">Desarrollado por: Reynaldo Trejo y Samuel Santos @ 022017</p>
</footer>

<script>
// Automatic Slideshow - change image every 4 seconds
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 4000);    
}

// Used to toggle the menu on small screens when clicking on the menu button
function myFunction() {
    var x = document.getElementById("navDemo");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}


</script>

</body>
</html>
