
		<!DOCTYPE html>
                <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<head>
    
<br>
<br>
    <title>Cita Taller</title>
    <div class="w3-top">
  <div class="w3-bar w3-black w3-card-2">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="/CrearCita.php"class="w3-bar-item w3-button w3-padding-large"></a>
    <a href="/PhpProject1/inicio.php">Salir</a>
    
    
       <div class="w3-dropdown-hover w3-hide-small">
      </div>
    </div>
    <a href="javascript:void(0)" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fa fa-search"></i></a>
  </div>
                
		<html lang="en">
		<style>
</style>
<body align = center >
    <h1 aling = center>Reserva tu cita</h1>
<table align = center>
       <img src="engine.jpg" class="w3-round w3-margin-bottom" alt="desde $25" style="width:60%">
      <img src="aceite.jpg" width="100" height="100" alt="descripcion de la imagen">
    <td align = left>Nombre </td>
    <td><input name="Nombre" type="text" id="nombre" size="40" /></td>
    <tr><td align = left>E-mail </td>
    <td><input name="email" type="text" id="email" size="40" /></td></tr>
    <tr><td align = left>Vehiculo </td>
    <td><input name="Vehiculo" type="text" id="vehiculo" size="40" /></td></tr>
    <tr><td align = left>Fecha </td>
    <td><input type="text" name="date1" id="date1" alt="date" class="IP_calendar" title="d/m/Y"></td></tr>
    
    
    
</table>
    <br>
    <br>
    </body>
		</html>
 
 
		








   